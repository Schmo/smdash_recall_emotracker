# Super Metroid DASH Recall Item Tracker Pack
This is an item tracker for the [Super Metroid DASH Recall randomizer](https://dashrando.github.io) for use with [EmoTracker](https://emotracker.net).  It has full item support, as well as autotracking on supported platforms.

# DASH Randomizer Information
The website for all things Dash can be found at the [DASH Randomizer](https://dashrando.github.io/) site.

## Thanks
[Dorkmaster Flek](https://github.com/DorkmasterFlek) - Created the DASH standard pack, which was the basis for the DASH Recall pack.  So huge thanks! 
